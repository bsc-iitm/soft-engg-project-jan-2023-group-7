python3 -m venv ../py
source ../py/bin/activate
pip install -r requirements.txt
python3 app.py